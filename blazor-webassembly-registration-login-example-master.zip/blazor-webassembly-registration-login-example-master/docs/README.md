# blazor-webassembly-registration-login-example

Standalone demo of code hosted on GitHub Pages at https://cornflourblue.github.io/blazor-webassembly-registration-login-example/
